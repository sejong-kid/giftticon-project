from unittest.util import _MAX_LENGTH
from django.db import models


class Giftmodel(models.Model):
    giftname=models.CharField(max_length = 100)
    maxdate=models.IntegerField()
    pinnum = models.IntegerField()
    theme=models.CharField(max_length = 100)
    themeimg=models.CharField(max_length = 100)
    class Meta:
        db_table = 'Giftmodel'


class Brandlist(models.Model):
    name = models.CharField( primary_key = True, max_length = 100) 
    category = models.CharField(max_length = 100)
    class Meta:
        db_table = 'brandlist'


class Typelist(models.Model):
    name = models.CharField(primary_key = True, max_length = 100) 
    
    class Meta:
        db_table = 'typelist'


class Imagelist(models.Model):
    urladdress = models.CharField(max_length = 100) 
    brand = models.ForeignKey(Brandlist, on_delete=models.SET_NULL, null =True)
    type = models.ForeignKey(Typelist, on_delete=models.SET_NULL, null =True)
    class Meta:
        db_table = 'imagelist'
