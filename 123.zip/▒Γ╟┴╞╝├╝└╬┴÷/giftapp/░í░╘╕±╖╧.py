import itertools
import re
with open('C://django/기프티체인지/가게목록.txt', 'r', encoding ='UTF-8') as f:
    a = f.read()
    b = re.split(':|\t|\n', a)
    x = []
    for i in b:
        c = i.split('\t')
        x.append(c)
    while [''] in x:
        x.remove([''])
    x = list(itertools.chain(*x))
    print(x)